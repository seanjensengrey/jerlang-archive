-module(jerlang_tests_vm).

-ifdef(TEST).
-include_lib("eunit/include/eunit.hrl").
-endif.

-ifdef(use_joins_vm).
-export([test_suite/0]).

clear_mailbox() ->
    receive
	M -> io:format("Mailbox entry: ~p~n", [M]),
	     clear_mailbox()
    after 0 ->
	    ok
    end.

read_mailbox() ->
    search
	Z -> io:format("Search found ~p~n", [Z]),
	     read_mailbox()
    after 0 -> 
	    ok
    end.

trace_loop() ->
    receive
	{trace, _, call, X} ->
	    io:format("Call: ~p~n", [X]);
	{trace, _, return_from, Call, Ret} ->
	    io:format("Return From: ~p => ~p~n", [Call, Ret]);
	Other ->
	    io:format("Other = ~p~n", [Other])
    end,
    trace_loop().

tracer() ->
    dbg:tracer(),
    dbg:tpl(vm_tests, '_',
	    dbg:fun2ms(fun(_) ->
			        nothing end)),
    dbg:p(all, [c]).

test_suite() ->
    ok = test_simple_search_pointer(),
    ok = test_simple_search(),
    ok = test_receive_and_search(),
    ok = test_reset_search(),
    ok = test_basic(),
    ok = test_search_order(),
    ok = test_last_message(),
    ok = test_search_index(),
    ok = test_receive_index(),
    ok = test_message_indexing(),

    io:format("Finished test-suite.~n", []).

test_simple_search_pointer() ->
    io:format("Starting simple_search_pointer test...~n", []),
    clear_mailbox(),
    self() ! one,
    self() ! two,
    self() ! three,
    %% Search first fragment
    ok = search
	     one ->
		 ok
	 after 0 ->
		 error
	 end,
    %% Pointer should be set on two, since no
    %% other message was sent and pointer should
    %% have been moved to the next one
    ok = search
	     Msg ->
		 Msg = two,
		 ok
	 after 0 ->
		 error
	 end,

    %% Attempt to look for non-existing message
    ok = search
	     none ->
		 error
	 after 0 ->
		 ok
	 end,
    
    %% Pointer should be at the end of the mailbox
    %% Search for 'three' should fail
    ok = search
	     three ->
		 error
	 after 0 ->
		 ok
	 end,
    
    %% Reset search pointer
    ok = search_reset(),
    ok = search
	     three ->
		 ok
	 after 0 ->
		 error
	 end,
    
    %% Set pointer at the beginning of the mailbox
    ok = search_reset(),
    ok = search
	     Msg2 ->
		 Msg2 = one,
		 ok
	 after 0 ->
		 error
	 end,
    ok.    
 
test_last_message()->
    io:format("Starting last_message test...~n", []),
    clear_mailbox(),
    search_reset(),
    
    self() ! one,
    self() ! two,
    self() ! three,
    
    ok = search
	none ->
	    error
    after 0 ->
	    ok
    end,
    
    ok = receive
	three ->
	    ok
    after 0 ->
	    error
    end,

    self() ! four,
    self() ! five,

    ok = search
	four ->
	    ok
    after 0 ->
	    error
    end,
    self() ! six,
    ok = receive
	     six ->ok
	 after 0 ->
		 error
	 end,
    self() ! seven,
    ok = search
	     seven -> ok
	 after 0 -> error
	 end,
    ok.

test_basic() ->
    io:format("Starting basic test...~n", []),
    clear_mailbox(),
    self() ! one,
    self() ! two,
    
    ok = search
	     z -> error
	 after 0 ->
		 ok
	 end,
    clear_mailbox(),
    self() ! three,
    timer:sleep(100),
    ok = search
	three -> ok
    after 0 ->
	    error
    end,
    ok.

test_search_order() ->
    io:format("Starting search_order test...~n", []),
    clear_mailbox(),

    self() ! {one, 1},
    self() ! {two, 1},
    self() ! {one, 1},
    self() ! {one, 2},

    ok = 
	search
	    {one, 1} ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx1} = last_search_index(),
    
    ok = 
	search
	    {one, 1} ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx2} = last_search_index(),
    
    false = (Idx1 == Idx2),
    true = (Idx1 < Idx2),
    ok =
	search
	    {one, 2} ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx3} = last_search_index(),
    true = (Idx2 < Idx3),

    ok = 
	receive
	    {one, 1} ->
		ok
	after 0 ->
		error
	end,

    undefined = erlang:search_index(Idx1),
    {one, 1}  = erlang:search_index(Idx2),
    [{messages, [{two, 1}, {one, 1}, {one, 2}]}] = 
	process_info(self(), [messages]),
    ok.

test_receive_and_search() ->
    io:format("Starting receive_and_search test...~n", []),
    clear_mailbox(),
    
    self() ! one,
    self() ! two,
    self() ! three,

    ok = search
	     two -> ok
	 after 0 ->
		 error
	 end,
    ok = receive
	     two -> ok
	 end,

    ok = search
	     three -> ok
	 after 0 ->
		 error
	 end,
    
    ok = search_reset(),
    ok = search
	     two -> error
	 after 0 ->
		 ok
	 end,
    
    ok = search_reset(),
    ok = receive
	     one -> ok
	 after 0 ->
		 ok
	 end,
    ok = search
	     Msg ->
		 Msg = three,
		 ok
	 after 0 ->
		 error
	 end,
    ok.

test_reset_search() ->
    io:format("Starting reset_search test...~n", []),
    clear_mailbox(),
    search_reset(),
    self() ! {one, 1},
    self() ! {one, 2},
    self() ! {two, 1},
    self() ! {two, 4},
    self() ! {two, 2},
    self() ! {two, 3},

    ok = search
	     {one, 2} -> ok
	 after 0 ->
		 error
	 end,

    ok = receive
	     {two, 1} -> ok
	 after 0 ->
		 error
	 end,
    ok = receive
	     {two, 4} -> ok
	 after 0 ->
		 error
	 end,
    
    ok = search
	     {two, 1} -> error;
	     {two, 4} -> error;
	     {two, 2} -> ok
	 after 0 ->
		 error
	 end,

    search_reset(),
    ok = search
	     {two, 2} -> ok
	 after 0 ->
		 error
	 end,
    ok.

test_simple_search() ->
    io:format("Starting simple_search test...~n", []),
    clear_mailbox(),

    self() ! {one, 1},
    self() ! {two, 1},
    self() ! {two, 2},
    self() ! {three, 1},

    ok = search
	     {one, _} -> ok
	 end,

    ok = search
	     {two, Z} -> 1 = Z,
			 ok
	 end,

    self() ! {two, 3},
    self() ! {two, 4},
    ok = receive
	{two, 3} -> ok
    end,
    ok = search
	     {two, 4} ->
		 ok
	 after 0 ->
		 error
	 end,

    self() ! {four, 1},
    ok = search
	     {two, 3} ->
		 error;
	     {four, 1} ->
		 ok
    after 0 ->
	    error
    end,
    ok = receive
	     M ->
		 M = {one, 1},
		 ok
	 after 0 ->
		 error
	 end,
    ok.

test_search_index() ->
    io:format("Starting search_index test...~n", []),
    clear_mailbox(),
    search_reset(),

    self() ! {one, 1},
    self() ! {two, 1},
    
    ok =
	search
	    {two, _} ->
		ok
	after 0 ->
		error
	end,
    {ok, Index} = last_search_index(),
    
    {two, 1} = erlang:search_index(Index),
    self() ! {two, 2},
    ok = 
	search
	    {two, _} ->
		ok
	after 0 ->
		error
	end,
    {ok, Index2} = last_search_index(),
    true = Index2 > Index,
    {two, 2} = erlang:search_index(Index2),
    [{messages,
      [{one, 1}, {two, 1}, {two, 2}]}] = 
	process_info(self(), [messages]),
    undefined = erlang:search_index(Index2 + 1),
    search_reset(),
    
    ok = search
	     {two, 2} ->
		 ok
	 after 0 ->
		 error
	 end,
    {ok, Index2} = last_search_index(),
    %%  search_index/1 does not depend on
    %%  on the search pointer in vm
    {one, 1} = erlang:search_index(Index - 1),
    
    ok = receive
	     {one, 1} ->
		 ok
	 after 0 ->
		 error
	 end,
    undefined = erlang:search_index(Index -1),
    ok.


test_receive_index() ->
    io:format("Starting receive_index test...~n", []),
    clear_mailbox(),

    self() ! one,
    self() ! one,
    self() ! two,
    self() ! one,
%    io:format("RECEIVE??? ~p~n", [process_info(self(), [messages])]),
    ok = 
	search
	    one ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx1} = last_search_index(),

    ok =
	search
	    one ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx2} = last_search_index(),

    ok = 
	search
	    one ->
		ok
	after 0 ->
		error
	end,
    {ok, Idx3} = last_search_index(),

    {ok, one} = erlang:receive_index(Idx3),

    [{messages,
      [one, one, two]}] = 
	process_info(self(), [messages]),

    ok = receive
	     one ->
		 ok
	 after 0 ->
		 error
	 end,
    [{messages,
      [one, two]}] = 
	process_info(self(), [messages]),

    undefined = erlang:receive_index(Idx1),
    {ok, one} = erlang:receive_index(Idx2),
    ok = receive
	     V ->
		 V = two,
		 ok
	 after 0 ->
		 error
	 end,

    [{messages,
      []}] = 
	process_info(self(), [messages]),   
    undefined = erlang:receive_index(Idx2),
    ok.

test_message_indexing() ->
    io:format("Starting message_indexing test...~n", []),
    clear_mailbox(),
    lists:foreach(
      fun(Elem) ->
	      undefined = erlang:search_index(Elem)
      end,
      lists:seq(0,1000)),

    ok.

-endif.
