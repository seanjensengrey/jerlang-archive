-module(ping_pong_test).

-ifdef(use_joins_vm).

-export([ping_init/2, pong/0]).
-export([start/0]).

-compile({parse_transform, jerlang_vm_parse}).

ping_init(Id, Pid) ->
%    search_debug(on),
    {A1, A2, A3} = now(),
    random:seed(A1+Id, A2*Id, A3),
    ping(Id, Pid).

ping(Id, Pid) ->
    timer:sleep(random:uniform(100)),
    Ref = make_ref(),
    Pid ! {ping, Ref, self()},
    io:format("Ping[~p]!~n", [Id]),
    receive
	{pong, Ref} -> 
	    ok
    end,
    ping(Id, Pid).

pong() ->
%    search_debug(on),
    {ok, Id} = receive
	{ping, Ref, Pid} ->
	    Pid ! {pong, Ref},
	    {ok, 1}
    end,
    io:format("Pong!~n", []),
%    io:format("Pong[~p]!~n", [Id]),
    pong().

start() ->
    PidPong = spawn(ping_pong_test, pong, []),
    [ spawn(ping_pong_test, ping_init, [X, PidPong]) || X <- [1,2, 3,4, 5, 6, 7, 8, 9]],
    receive
	nothing -> exit({error, wrong_receive})
    end.

-endif.
