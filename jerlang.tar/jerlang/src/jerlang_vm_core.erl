-module(jerlang_vm_core).

-ifdef(use_joins_vm).

-export([test_raw/0]).
-export([loop/4]).
-import(jerlang_misc, [convert_now/1]).

-include("jerlang.hrl").

-define(CASE_TEST_GUARD, test_entry).
-define(CASE_RUN_ACTION, run_all).


-spec(loop/4 :: (fun((timeout(), ref()) -> any()),
		 [alpha()],
		 [receive_fun_test()],
		 receive_timeout()) -> {'ok', any()}).

check_invalid_timeout([{timeout, Timeout, _}])
  when (Timeout == infinity) ->
    ok;
check_invalid_timeout([{timeout, Timeout, _}])
  when (not(is_number(Timeout))) orelse (Timeout < 0) ->
    exit({error, {invalid_timeout, Timeout}});
check_invalid_timeout(_) ->
    ok.

loop(Search, Joins, Actions, Options) ->
    ok = check_invalid_timeout(Options),
%    io:format("OPTIONS: ~p~n", [Options]),
    Opt = parse_options(Options),
    search_reset(),
    receive_loop(Search, Joins, Actions, Opt).

parse_options([]) ->
    #opt{timeout=infinity,
	 t_action=none,
	 timer=disabled};
parse_options([{timeout, Timeout, TAction}]) ->
    #opt{timeout=Timeout,
	 t_action=TAction,
	 timer=disabled}.

receive_loop(Search, Joins, Actions, Opt) ->
%    io:format("Receive_loop: ~p~n", [Opt]),
    {Timeout, NOpt} = process_timeout(Opt),
%    io:format("Receive_loop2: ~p|~p~n", [Timeout, NOpt]),
    receive_with_timeout(Search, Joins, Actions,
			 NOpt, Timeout).

receive_with_timeout(_Search, _Joins, _Action,
		     #opt{t_action=TAction}, Timeout)
  when (Timeout < 0) ->
    TAction();    
receive_with_timeout(Search, Joins, Actions,
		     Opt, Timeout)
  when (Timeout >= 0) orelse (Timeout == infinity) ->

    Ref = make_ref(),
    Result = Search(Timeout,Ref),
    case Result of
	{timeout, Ref} ->
	    timeout_action(Search, Joins, Actions, Opt);
	M ->
	    {ok, Index} = last_search_index(),
	    NOpt = update_timeout(Opt),
	    message(process_join({Index, M}, Joins, Actions, []),
		    Search, Actions, NOpt)
    end.

process_timeout(#opt{timer=disabled} = Opt) ->
    {0, Opt};
process_timeout(#opt{timeout=infinity} = Opt) ->
    {infinity, Opt};
process_timeout(#opt{timeout=0} = Opt) ->
    {0, Opt};
process_timeout(#opt{timeout=Timeout} = Opt) when (Timeout < 0) ->
    {Timeout, Opt};
process_timeout(#opt{timeout=Timeout} = Opt) ->
    {Timeout, Opt#opt{s_time=(convert_now(erlang:now()))}}.

update_timeout(#opt{timer=disabled} = Opt) ->
    Opt;
update_timeout(#opt{timeout=infinity} = Opt) ->
    Opt#opt{timer=disabled};
update_timeout(#opt{s_time=Time, timeout=Limit} = Opt) ->
    Opt#opt{timeout=(Limit-(convert_now(erlang:now())-Time)),
	    timer=disabled}.

timeout_action(_, _, _, #opt{timer=enabled, t_action=TAction}) ->
    TAction();
timeout_action(Search, Joins, Actions, Opt) ->
    receive_loop(Search, Joins, Actions,
		 Opt#opt{timer=enabled}).
    

message({ok, Result}, _, _, _) ->
    Result;
message({error, NJoins}, Search, Actions, Options) ->
    receive_loop(Search, NJoins, Actions, Options).

process_join({_, _}, [], _, JoinsTests) ->
    {error, lists:reverse(JoinsTests)};
process_join({Id, Msg}, [JoinTests | JoinsRest],
	     [JoinAction | ActionsRest],
	     JoinsTests) ->

    %%  FIXME: Update variable is useless here, since always
    %%  at least one is satisfied
    {NJoin, Update} = 
	lists:mapfoldl(
		fun({PId, #pattern_joins{test=F, msgs=Msgs} = PRec} = P, S) ->
			case F(Msg) of
			    true ->
				{{PId, PRec#pattern_joins{msgs=Msgs ++ [Id]}},
				 yes};
			    _ ->
				{P, S}
			end
		end, no, JoinTests),

    Result1 = check_joins(Update, NJoin, JoinAction, Id),
    case run_joins(Result1, JoinAction, NJoin) of
	{error, _} ->
	    process_join({Id, Msg}, JoinsRest, ActionsRest,
			 [NJoin | JoinsTests]);
	Other  -> Other
    end.
    
check_joins(no, _, _, _) ->
    {error, no_match};
check_joins(yes, JoinPatterns, Action, Id) ->
    PMsgs = lists:map(
      fun({_, #pattern_joins{msgs=Msgs}}) ->
	      Msgs
      end, JoinPatterns),
    %% Either returns error or found set
    jerlang_mset:common_sets(
      PMsgs, {fun partial_run/2, Action, Id}).

partial_run(MsgIds, Action) ->
    MatchedMsgs = get_messages(MsgIds, [], fun erlang:search_index/1),
    try Action(MatchedMsgs, ?CASE_TEST_GUARD) of
	true ->
	    {ok, MsgIds, MatchedMsgs};
	false ->
	    error
    catch
	error:{badmatch, _} ->
	    error
    end.

get_messages([], Result, _) ->
    lists:reverse(Result);
get_messages([Head | Rest], Result, F) ->
    get_messages(Rest, [F(Head) | Result], F).

run_joins({ok, MsgIds, Messages}, Action, Joins) ->
    FilteredIds = propagation_filter(MsgIds, Joins, []),
    ok = purge_process_mailbox(FilteredIds),
    {ok, Action(Messages, ?CASE_RUN_ACTION)};
run_joins({error, _} = Error, _, _) ->
    Error.

purge_process_mailbox([]) ->
    ok;
purge_process_mailbox([Id | Rest]) ->
    {ok, _Msg} = erlang:receive_index(Id),
    purge_process_mailbox(Rest).

propagation_filter([], [], Result) ->
    lists:reverse(Result);
propagation_filter([Id | IdRest], [{_, #pattern_joins{prop=no}} | Rest], Result) ->
    propagation_filter(IdRest, Rest, [Id | Result]);
propagation_filter([Id | IdRest], [{_, #pattern_joins{prop=yes}} | Rest], Result) ->
    propagation_filter(IdRest, Rest, Result).

test_raw() ->
%    self() ! single,
    self() ! {one, 12},
    self() ! {two, 2},
    self() ! three,

    A = 12,

%    self() ! single,
    self() ! {four, 17},
    self() ! {five, 6},
    %%    self() ! five,
    R2 = loop(
	   fun(Timeout, Ref) ->
		   search
		       single -> single;
		       {four, SomeInt} -> {four, SomeInt};
		       {five, Int} -> {five, Int}
		   after Timeout ->
			   {timeout, Ref}
		   end
	   end,
	   [[{1, #pattern_joins{test=
			  fun(Value) ->
				  case Value of
				      single -> true;
				      _ -> false
				  end
			  end, msgs=[]}}],
	    [{2, #pattern_joins{test=
			  fun(Value) ->
				  case Value of
				      {four, SomeInt} -> true;
				      _ -> false
				  end
			  end, msgs=[]}},
	     {3, #pattern_joins{test=
			  fun(Value) ->
				  case Value of
				      {five, Int} -> true;
				      _ -> false
				  end
			  end, msgs=[]}}]],
   
    %% TODO how assignment in receive changes things?
	   [fun(Res1, Case) ->
		    [single] = Res1,
		    Ret = true,
		    case Case of
			test_entry -> Ret;
			run_all ->
			    io:format("Three !~n", []),
			    {finished, single}
		    end
	    end,
	    fun(Res2, Case) ->
		    [{four, Z}, {five, I}] = Res2,
		    Ret = is_integer(Z) andalso (Z > 15) and (I > 3),
		    case Case of
			test_entry -> Ret;
			run_all ->
			    io:format("Four !~n", []),
			    {finished_second, {Z, I}}
		    end
	    end],
	   [{timeout, 10000,
	     fun() ->
		     io:format("Timeout occured~n", []),
		     timeout_ok
	     end}]),
    io:format("Finished the second receive with: ~p~n", [R2]).

%test() ->
%    C = 15,
%    A = 12,
%    self() ! {one, 12},
%    self() ! {two, 2},
%    self() ! three,
%
%    receive
%	three ->
%	    {ok, C};
%	{one, A} and {two, B} ->
%	    {ok, {A, B}}
%    end.

-endif.
