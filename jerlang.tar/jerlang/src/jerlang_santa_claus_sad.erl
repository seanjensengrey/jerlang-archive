-module(jerlang_santa_claus_sad).
-export([start/0]).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.

santa() ->
    io:format("It was a long night. Time to bed~n"),
    Group = 
	receive
	    {reindeer, Pid1} and {reindeer, Pid2} and {reindeer, Pid3} 
	      and {reindeer, Pid4} and {reindeer, Pid5} and {reindeer, Pid6}
	      and {reindeer, Pid7} and {reindeer, Pid8} and {reindeer, Pid9} ->
		io:format("Ho, ho, ho! Let's deliver presents!~n"),
		[Pid1, Pid2, Pid3, Pid4,
		 Pid5, Pid6, Pid7, Pid8, Pid9];
	    {ork, sergant, Pid1} and {ork, captain, Pid2} and {ork, sergant, Pid3} ->
		io:format("Ho, ho, ho? No presents this year. Orks destroyed the factory!~n"),
		[Pid1, Pid2, Pid3];
	    {elf, Pid1} and {elf, Pid2} and {elf, Pid3} ->
		io:format("Ho, ho, ho! Let's discuss R&D possibilites!~n"),
		[Pid1, Pid2, Pid3]
	end,
    [ Pid ! ok || Pid <- Group],
    santa().

worker(Santa, Type, Id, Action) ->
    generate_seed(Id),
    worker1(Santa, Type, Id, Action).
    
worker1(Santa, {ork, Type}, Id, Action) ->
    receive after random:uniform(8000) -> ok end,
    Santa ! {ork, Type, self()},
    io:format("~p '~p' ~p: Waiting at the gate~n", [ork, Type, Id]),
    receive ok -> ok end,
    io:format("~p '~p' ~p: ~p~n", [ork, Type, Id, Action]),
    worker1(Santa, {ork, Type}, Id, Action);
worker1(Santa, Type, Id, Action) ->
    receive after random:uniform(4000) -> ok end,
    Santa ! {Type, self()},
    io:format("~p ~p: Waiting at the gate~n", [Type, Id]),
    receive ok -> ok end,    
    io:format("~p ~p: ~p~n", [Type, Id, Action]),
    worker1(Santa, Type, Id, Action).

generate_seed(Seed) ->
    {A1, A2, A3} = now(),
    random:seed(A1+Seed, A2*Seed, A3).

start() ->
    Santa = spawn(fun() -> santa() end),
    [spawn(fun() -> worker(Santa, reindeer, I, " delivering toys.\n") end)
     || I <- lists:seq(1, 9)],
    [spawn(fun() -> worker(Santa, elf, I, " meeting in the study.\n") end)
     || I <- lists:seq(1, 10)],
    [spawn(fun() -> worker(Santa, {ork, sergant}, I, " destroying presents.\n") end)
     || I <- lists:seq(1,4)],
    spawn(fun() -> worker(Santa, {ork, captain}, 5, " making orders.\n") end).
