-module(nata_subscribe).

-include("nata.hrl").

-export([start/1]).

-define(CHANNLE, a).
-define(EXCHANGE, nata_exchange).
-define(CHMODULE, nata_channel).

start(Conf) ->
    NConf = init(Conf),
    consume(NConf).

consume({_, Id, _, _, _}=Conf) ->
    receive
	{channel, Name, Msg} ->
	    io:format("[Subscriber ~p]: Received ~p on [~p]~n",
		      [Id, Msg, Name]),
	    ok;
	stop ->
	    %% Should be synchronous
	    %% should cancell the subscriptins first
	    exit(normal)
    end,
    consume(Conf).

init({Exchange, Id, Key, Synchr, Channels}) ->
    {ok, CHPids} = Exchange:create_route(Key, Synchr, Channels),
    lists:foreach( fun(Ch) -> ?CHMODULE:subscribe(Ch) end, CHPids),
    {Exchange, Id, Key, Synchr, CHPids}.
    
