-module(nata_channel).

-behaviour(gen_server).

%% API
-export([start_link/1]).

-export([init/1, handle_call/3, handle_cast/2, handle_info/2,
	 terminate/2, code_change/3]).

-export([subscribe/1, unsubscribe/1, route/3]).

-record(state, {name, msgs, subs=[]}).
-define(SERVER, gen_server).


start_link(Name) ->
    ?SERVER:start_link(?MODULE, [Name], []).

init([Name]) ->
    {ok, #state{name=Name, msgs=queue:new()}}.

subscribe(ChPid) ->
    ?SERVER:call(ChPid, consume).

unsubscribe(ChPid) ->
    ?SERVER:call(ChPid, not_consume).

%%  -------------------------------------------------------
route(ChPid, Key, Msg) ->
    ?SERVER:cast(ChPid, {msg, Key, Msg}).



%%  -------------------- CALLBACKS ------------------------

handle_cast({msg, Key, Msg}, #state{msgs=Q, subs=[]}=S)  ->
    {noreply, S#state{msgs=queue:in(Q, {Key, Msg})}};
handle_cast({msg, Key, Msg}, #state{name=N, subs=Subs}=S) ->
    io:format("[Channel ~p] Notify of ~p~n", [N, Msg]),
    notify_subscribers(Msg, Key, Subs),
    {noreply, S};
handle_cast(_, State) ->
    {noreply, State}.

handle_call(consume, {From, _}, #state{name=N, msgs=Q, subs=[]}=S) ->
    io:format("[Channel ~p] First consumer ~p~n", [N, From]),
    notify_with_old_messages(Q, From),
    {reply, ok, S#state{msgs=queue:new(), subs=[From]}};
handle_call(consume, {From, _}, #state{name=N, subs=Subs} = S) ->
    io:format("[Channel ~p] Consumer ~p~n", [N, From]),
    {reply, ok, S#state{subs=[From | Subs]}};
handle_call(_, _, State) ->
    {noreply, State}.

handle_info(_Info, State) ->
    {noreply, State}.

terminate(_Reason, _State) ->
    ok.

code_change(_OldVsn, State, _Extra) ->
    {ok, State}.

%%--------------------------------------------------------------------
%%% Internal functions
%%--------------------------------------------------------------------

notify_subscribers(_, _, []) ->
    ok;
notify_subscribers(Msg, Key, [S | Rest]) ->
    S ! {channel, Key, Msg},
    notify_subscribers(Msg, Key, Rest).

notify_with_old_messages(Q, Subs) ->
    L = queue:to_list(Q),
    notify(L, Subs).

notify([], _) ->
    ok;
notify([{Key, M} | Rest], Subs) ->
    Subs ! {channel, Key, M},
    notify(Rest, Subs).
