-module(jerlang_philosophers).
-export([philosopher/4,
	 fork/2,
	 waiter/2,
	 test/0]).

-compile({parse_transform, jerlang_parse}).

philosopher(Left, Right, Name, Waiter) ->
    philosopher_think(Name),
    Waiter ! {order, self(), Left, Right},
    receive
	{fork, Left} and {fork, Right} ->
	    philosopher_eat(Name)
    end,
    Waiter ! {finished, Left, Right},
    philosopher(Left, Right, Name, Waiter).

philosopher_eat(Name) ->
    io:format("Philosopher ~p eats...~n", [Name]),
    timer:sleep(random:uniform(1000)).

philosopher_think(Name) ->
    io:format("Philosopher ~p thinks...~n", [Name]),
    timer:sleep(random:uniform(1000)).

fork(Waiter, Number) ->
    receive
	{phil, Phil} ->
	    Phil ! {fork, self()}
    end,
    fork(Waiter, Number).

waiter(Name, Forks) ->
    NForks = 
	receive
	    {order, Phil, Left, Right} when lists:member(Left, Forks)
				   and lists:member(Right, Forks) ->
		Left ! {phil, Phil},
		Right ! {phil, Phil},
		Forks -- [Left, Right];
	    {initial, F} ->
		F;
	    {finished, Left, Right} ->
		Forks ++ [Left, Right]
	end,
    waiter(Name, NForks).

test() ->
    Size = 3,
    W = spawn(?MODULE, waiter, [adam, []]),
    ForksList =
	[{Id, spawn(?MODULE, fork, [W, Id])} || Id <- lists:seq(1, Size)],
    Forks = dict:from_list(ForksList),
    NForks = dict:store(0, dict:fetch(Size, Forks), Forks),
    F = lists:map(fun({_, V}) -> V end, ForksList),
    W ! {initial, F},
    [spawn(?MODULE, philosopher, [dict:fetch(Id, NForks),
				 dict:fetch(Id - 1, NForks), Id, W])
	  || Id <- lists:seq(1,Size)],
    receive
	ok ->
	     nothing
    end.
