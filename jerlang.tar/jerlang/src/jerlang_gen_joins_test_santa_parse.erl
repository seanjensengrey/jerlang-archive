-module(jerlang_gen_joins_test_santa_parse).
-compile({parse_transform, jerlang_gen_joins_parse}).

-behaviour(jerlang_gen_joins).

-export([init/1, handle_join/2, terminate/0]).
-export([start/0, stop/0, elf/0, reindeer/0]).
-export([elf_done/0, reindeer_done/0, status/1]).

start() ->
    jerlang_gen_joins:start({global, ?MODULE}, ?MODULE, [], []).

stop() ->
    jerlang_gen_joins:call({global, ?MODULE}, stop).

terminate() ->
    ok.

init(_) ->
    {ok, {{0,0}, sleeping}}.

elf() ->
    jerlang_gen_joins:call({global, ?MODULE}, elf, infinity),
    ok.

elf_done() ->
    jerlang_gen_joins:cast({global, ?MODULE}, {done, elf}).

reindeer() ->
    jerlang_gen_joins:call({global, ?MODULE}, reindeer, infinity).

reindeer_done() ->
    jerlang_gen_joins:cast({global, ?MODULE}, {done, reindeer}).

status(Status) ->
    jerlang_gen_joins:call({global, ?MODULE}, {status, Status}, infinity).

handle_join({status, {A, B}}, {{C, D}, _}=S) when ((A =< C) and (B =< D))  ->
    io:format("I am done ~p~n", [{C, D}]),
    {[{reply, ok}], S};
handle_join(stop, _) ->
    io:format("Stopping the server~n", []),
    {stop, normal};
handle_join({done, reindeer} and {done, reindeer} and {done, reindeer} and
	    {done, reindeer} and {done, reindeer} and {done, reindeer} and
	    {done, reindeer} and {done, reindeer} and {done, reindeer},
	    {Counter, awake_reindeer}) ->
    io:format("All reindeers returned~n",[]),
    {[ noreply || _ <- lists:seq(1,9)], {Counter, sleeping}};

handle_join({done, elf} and {done, elf} and {done, elf},
	    {Counter, awake_elf}) ->
    io:format("All elves returned~n",[]),
    {[ noreply || _ <- lists:seq(1,3)], {Counter, sleeping}};

handle_join(reindeer and reindeer and reindeer and
	    reindeer and reindeer and reindeer and
	    reindeer and reindeer and reindeer,
	    {{Reindeers, Elves}, sleeping}) ->
    io:format("Ho, ho, ho! Let's deliver presents~n",[]),
    {[ {reply, ok} || _ <- lists:seq(1,9)], {{Reindeers+1, Elves}, awake_reindeer}};

handle_join(elf and elf and elf,
	    {{Reindeers, Elves}, sleeping}) ->
    io:format("Ho, ho, ho! Let's discuss R&D possibilities~n",[]),
    {[ {reply, ok} || _ <- lists:seq(1,3)], {{Reindeers, Elves+1}, awake_elf}}.
