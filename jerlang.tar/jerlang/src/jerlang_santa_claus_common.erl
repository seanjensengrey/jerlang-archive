-module(jerlang_santa_claus_common).
-export([santa/0, worker/4, secretary0/1]).
-export([start/0]).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.


secretary0(SantaPid) ->
    self() ! {reindeers, 9},
    self() ! {elves, 3},
    secretary({[], []}, SantaPid).

secretary({Elves, Reindeers}, SantaPid) ->
    {Res, Wait} = 
	receive
	    {reindeer, Pid} and {reindeers, 1} ->
		self() ! {reindeers, 9},
		notify_santa(reindeers, SantaPid, [Pid | Reindeers]),
		{{Elves, []}, true};
	    {reindeer, Pid} and {reindeers, N} ->
		self() ! {reindeers, N - 1},
		{{Elves, [Pid | Reindeers]}, false};
	    {elf, Pid} and {elves, 1} ->
		self() ! {elves, 3},
		notify_santa(elves, SantaPid, [Pid | Elves]),
		{{[], Reindeers}, true};
	    {elf, Pid} and {elves, N} ->
		self() ! {elves, N - 1},
		{{[Pid | Elves], Reindeers}, false}
	end,
    ok = wait_for_santa(Wait),
    secretary(Res, SantaPid).

wait_for_santa(true) ->
    receive {santa, back} -> ok end;
wait_for_santa(_) ->
    ok.

notify_santa(Animal, Santa, Pids) ->
    Santa ! {wakeup, self(), Animal, Pids}.

notify(Pids) ->
    lists:foreach(
      fun(Pid) ->
	      Pid ! continue
      end, Pids).

santa() ->
    Pid = 
	receive
	    {wakeup, Secretary, Animal, Pids} ->
		santa_says(Animal),
		notify(Pids),
		Secretary
	end,
    timer:sleep(random:uniform(1000)),
    io:format("Santa is back. Going to sleep~n", []),
    Pid ! {santa, back},
    santa().

worker(Type, Secretary, Id, String) ->
    timer:sleep(random:uniform(1000)),
    Secretary ! {Type, self()},
    receive
	continue ->
	    ok
    end,
    worker(Type, Secretary, Id, String).
    

santa_says(reindeers) ->
    io:format("Ho, ho, ho! Let's deliver presents!~n", []);
santa_says(elves) ->
    io:format("Ho, ho, ho! Let's discuss R&D possibilities!~n", []).
    
start() ->
    Santa = spawn(?MODULE, santa, []),
    Secretary = spawn(?MODULE, secretary0, [Santa]), 
    [ spawn(?MODULE, worker, 
	    [elf, Secretary, X, "Elf "]) || X <- [1,3] ],
    [ spawn(?MODULE, worker,
	    [reindeer, Secretary, X, "Reindeer "]) || X <- [1,3,4,7,8,9] ],
    [ spawn(?MODULE, worker,
	    [elf, Secretary, X, "Elf "]) || X <- [2,4,5] ],
    [ spawn(?MODULE, worker,
	    [reindeer, Secretary, X, "Reindeer "]) || X <- [2,5,6] ].
