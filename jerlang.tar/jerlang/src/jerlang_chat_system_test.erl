-module(jerlang_chat_system_test).
-export([test/0, new_user/1]).
-define(SYSTEM, jerlang_chat_system).

-define(ROOT, admin).
-define(USER1, lukasz).
-define(USER2, emilka).

test() ->
    ?SYSTEM:start(),
    spawn_link(?MODULE, new_user, [?USER1]),
    spawn_link(?MODULE, new_user, [?USER2]),
    ?SYSTEM:login(?ROOT),
    ?SYSTEM:send(?ROOT, test_msg),
    {room, Room} = ?SYSTEM:private_channel(?ROOT, ?USER1),
    ?SYSTEM:send(?ROOT, Room, test_msg_private),
    receive
	ok ->
	    ok
    end.


new_user(Name) ->
    ?SYSTEM:login(Name),
    ok = 
	receive
	    {chat, public, User, Msg} ->
		io:format("[~p]:Received message [~p] from [~p]~n",
			  [Name, Msg, User]),
		ok
	after 1000 ->
		error
	end,
    new_user0(Name).

new_user0(?USER1=User) ->
    {room, Room} = ?SYSTEM:private_channel(User, ?ROOT),
    ok =
	receive
	    {chat, private, Room, Sender, Msg} ->
		io:format("[~p]:Received '~p' on private channel from [~p]~n",
			  [User, Msg, Sender]),
		ok
	after 1000 ->
		error
	end;
new_user0(?USER2) ->
    ok = 
	receive
	    _ ->
		error
	after 1000 ->
		ok
	end.
