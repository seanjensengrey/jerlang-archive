-module(nata_exchange).

-compile({parse_transform, jerlang_gen_joins_parse}).

-include("nata.hrl").

-behaviour(jerlang_gen_joins).

-export([init/1, handle_join/2, start/0, terminate/0]).
-export([create_route/3, delete_route/1]).
-export([publish/1]).

-define(CHMODULE, nata_channel).
-define(SERVER, jerlang_gen_joins).
-define(MAX, 4).

init(_) ->
    {ok, {dict:new(), dict:new()}}.

start() ->
    ?SERVER:start({local, ?MODULE}, ?MODULE, [], []).

terminate() ->
    ?SERVER:call(?MODULE, stop).

create_route(Key, Synchr, Channels) ->
    ?SERVER:call(?MODULE, {route, Key, Synchr, Channels}).

delete_route(Key) ->
    ?SERVER:call(?MODULE, {remove_route, Key}).

publish(Msg) ->
    ?SERVER:cast(?MODULE, Msg).

%% ----------------------- CALLBACKS ----------------------

handle_join({route, Key, Synchr, Channels}, Status)
  when ((Synchr > 0) and (Synchr < ?MAX)) ->
    %% Whenever rout already exists we only update
    %% the number of channels

    io:format("[Ex] Create route ~p~n", [Key]),
    {Reply, NS} = 
	try
	    {Pids, {NewRoute, UpdatedS}} =
	    get_route(Key, Synchr, Channels, Status),
	    ok = set_route(NewRoute, Key, Synchr),
	    {{ok, Pids}, UpdatedS} 
	catch
	    throw:_ ->
		{{error, {invalid_synchr, Synchr}}, Status}
	end,
    {[{reply, Reply}], NS};
handle_join({remove_route, Key} and {route, Key, _}, Status) ->
    NS = remove_route(Key, Status),
    {[{reply, ok}, noreply], NS};
handle_join(#msg{key=none}, Status) ->
    io:format("[Ex] Invalid message. Key required~n", []),
    {[noreply], Status};
handle_join(#msg{key=Key, value=V1} and #msg{key=Key, value=V2}
	    and prop({route, Key, 2}), Status) ->
    route_message(Key, [V1, V2], Status),
    {[noreply || _ <- lists:seq(1, 3)], Status};
handle_join(#msg{key=Key, value=V1} and
	    #msg{key=Key, value=V2} and
	    #msg{key=Key, value=V3} and
	    prop({route, Key, 3}),
	    Status) ->

    route_message(Key, [V1, V2, V3], Status),
    {[noreply || _ <- lists:seq(1,4)], Status}.

%%  --------------------------------------------------
%%  ---- INTERNAL FUNCTIONS --------------------------

get_route(Key, Synchr, ChNames, {S1, S2}) ->
    {Update, NS1} =
	case dict:find(Key, S1) of
	    {ok, {Synchr, Values}} ->
		NChNames = (Values ++ (ChNames -- Values)),
		{no, dict:store(Key, {Synchr, NChNames}, S1)};
	    {ok, _} ->
		throw(invalid_synchr);
	    error ->
		{yes, dict:store(Key, {Synchr, ChNames}, S1)}
	end,
    {ChPids, NS2} =
	start_channels(ChNames, S2),
    {ChPids, {Update, {NS1, NS2}}}.
    

set_route(yes, Key, Synchr) ->
    ?SERVER:cast(?MODULE, {route, Key, Synchr}),
    ok;
set_route(_, _, _) ->
    ok.

route_message(Key, Value, {S1, S2}) ->
    {_, ChNames} = dict:fetch(Key, S1),
    ChPids = lists:map(
		 fun(Name) ->
			 dict:fetch(Name, S2)
		 end, ChNames),
    lists:map(
      fun(Pid) ->
	      ?CHMODULE:route(Pid, Key, Value)
      end, ChPids).

start_channels(Channels, Store) ->
    start_channels(Channels, [], Store).

start_channels([], Result, Store) ->
    {lists:reverse(Result), Store};
start_channels([Ch | Rest], Result, Store) ->
    {Pid, NS} =
	case dict:find(Ch, Store) of
	    {ok, ChPid} ->
		{ChPid, Store};
	    error ->
		{ok, ChPid} = ?CHMODULE:start_link(Ch),
		NStore = dict:store(Ch, ChPid, Store),
		{ChPid, NStore} 
	end,
    start_channels(Rest, [Pid | Result], NS).

remove_route(Key, Status) ->
    %% TODO: we should possibly check if the channels
    %% of the key are attached to any other channel
    %% If not, then maybe we should terminate them?
    dict:erase(Key, Status).
