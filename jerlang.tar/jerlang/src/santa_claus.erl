-module(santa_claus).
-export([elf/2, reindeer/2, ork/2]).
-export([santa/3]).
-export([start/0, start/2]).
-export([start_timer/0, start_timer/1]).

-import(jerlang_misc, [generate_seed/1]).

%% Santa claus problem that allows for limited number of
%% synchronisations, solved using standard Erlang semantics.
%% Inspired by Richard A. O'Keefe solution at
%% http://www.cs.otago.ac.nz/staffpriv/ok/santa/santa.erl
%% We provide additional information to ensure message
%% correctness. Also the worker processes are not created
%% sequentially in one go, to create more non-determinism.

worker(Santa, Type, Id, String) ->
    receive
    after random:uniform(1000) -> ok end,
    Ref = make_ref(),
    Santa ! {Type, self(), Ref},
    io:format("~p[~p]: ~p~n", [Type, Id, String]),
    receive
	{Ref, done} -> ok
    end,
    receive after random:uniform(100) -> ok end,
    Santa ! {job_done, Type, self(), Ref},
    receive
	{Ref, finished} -> ok
    end,
    worker(Santa, Type, Id, String).

elf(Id, Santa) ->
%    search_debug(on),
    generate_seed(Id),
    worker(Santa, elf, Id, "In the waiting hall").

reindeer(Id, Santa) ->
%    search_debug(on),
    generate_seed(Id),
    worker(Santa, reindeer, Id, "Waiting in the stable for a ride").

ork(Id, Santa) ->
    generate_seed(Id),
    receive after random:uniform(1000) -> ok end,
    Santa ! {ork, self()},
    io:format("Ork [~p] sent an arrow~n", [Id]),
    ork(Id, Santa).

notify_workers([], _) ->
    ok;
notify_workers([{Pid, Ref} | Rest], Message) ->
    Pid ! {Ref, Message},
    notify_workers(Rest, Message).

wait_confirmation([]) ->
    ok;
wait_confirmation([{Pid, Ref} | Rest]) ->
    receive
	{job_done, _Type, Pid, Ref} -> ok
    end,
    wait_confirmation(Rest).    

santa(Reindeers, Elves, Limits) ->
    santa0({[], Reindeers}, {[], Elves}, Limits, {0, 0}).

santa0({Reindeers, RMin}, P2, L, {RN, EN})
  when (length(Reindeers) >= RMin) ->
    {ok, Result} = wakeup_santa(Reindeers, RMin,
			  "Reindeers delivering presents"),
    
    santa_continuation({Result, RMin}, P2, L, {RN+1, EN});
santa0(P1, {Elves, EMin}, L, {RN, EN}) when (length(Elves) >= EMin) ->
    {ok, Result} = wakeup_santa(Elves, EMin,
			  "Elves discussing R&D possibilities"),
    santa_continuation(P1, {Result, EMin}, L, {RN, EN+1});
santa0(P1, P2, L, C) ->
    santa1(P1, P2, L, C).

santa_continuation(_, _, {RLimit, ELimit}, {RN, EN}) 
  when (RLimit =< RN) and (ELimit =< EN) ->
    io:format("Simulation finished [~p | ~p] for [~p | ~p]~n",
	      [RN, EN, RLimit, ELimit]);
santa_continuation(P1, P2, Limits, N) ->
    santa0(P1, P2, Limits, N).

wakeup_santa(All, Min, Text) ->
    {Rest, Group} = lists:split(length(All) - Min, All),
    notify_workers(Group, done),
    io:format("Santa: ~p~n", [Text]),
    wait_confirmation(Group),
    notify_workers(Group, finished),
    io:format("Santa: \"Going to sleep\"~n", []),
    {ok, Rest}.
    
santa1({Reindeers, RMin}, {Elves, EMin}, L, C) ->
%    io:format("Santa: Reindeers = ~p, Elves = ~p~n", [length(Reindeers),
%						      length(Elves)]),
    {RReindeers, RElves} = receive
			       {reindeer, Pid, Ref} ->
				   {[{Pid, Ref} | Reindeers], Elves};
			       {elf, Pid, Ref} ->
				   {Reindeers, [{Pid, Ref} | Elves]};
			       {ork, _Pid} ->
				   {Reindeers, Elves};			       
			       _  ->
				   exit({error, unexpected_message})
			   end,
    santa0({RReindeers, RMin}, {RElves, EMin}, L, C).

start() ->
    start(?MODULE, {infinite, infinite}).

start(Module, Limits) ->
    [ spawn(santa_claus, elf, [X, self()]) || X <- [1,3] ],
    [ spawn(santa_claus, reindeer, [X, self()]) || X <- [1,3,4,7,8,9] ],
    [ spawn(santa_claus, elf, [X, self()]) || X <- [2] ],
    [ spawn(santa_claus, reindeer, [X, self()]) || X <- [2,5,6] ],
    [ spawn(santa_claus, ork, [X, self()]) || X <- [1,2,3,4,5]],

    Module:santa(9, 3, Limits).

start_timer() ->
    start_timer(?MODULE).

start_timer(Module) ->
    {Time, _} = timer:tc(Module, start, [Module, {100, 100}]),
    io:format("Executed in ~p seconds~n", [(Time/1000000)]),
    ok.
