-module(multiple_producers).
-compile({parse_transform, jerlang_gen_joins_parse}).

-behaviour(jerlang_gen_joins).

-export([init/1, handle_join/2, terminate/0]).
-export([start/0, stop/0]).
-export([notify/0, notify/1, credentials/2,
	deposit/1, sell/2, buy/3]).

-record(packet,{id, value}).

-define(LIMIT, 250).
-define(GEN_JOINS, jerlang_gen_joins).

start() ->
    ?GEN_JOINS:start({local, ?MODULE}, ?MODULE, [], []).

stop() ->
    ?GEN_JOINS:call(?MODULE, stop).

terminate() ->
    ok.

init(_) ->
    {ok, 0}.

notify() ->
    ?GEN_JOINS:call(?MODULE, notify, infinity).

notify(Timeout) ->
    ?GEN_JOINS:call(?MODULE, notify, Timeout).

sell(Id, Value) ->
    ?GEN_JOINS:cast(?MODULE, #packet{value=Value, id=Id}).

buy(Id, Value, Previous) ->
    ?GEN_JOINS:cast(?MODULE, {buy, Id, Value, Previous}).

credentials(Id, Password) ->
    ?GEN_JOINS:cast(?MODULE, {secure, Id, Password}).

deposit(V) ->
    ?GEN_JOINS:cast(?MODULE, {deposit, V}).

%% JOINS

handle_join(notify and #packet{value=V1, id=Id}
	    and {buy, Id, _, _Previous},
	   Current) ->
    {[{reply, {ok, buy, Id}}, noreply, noreply],
     Current - V1};
handle_join(notify and {deposit, V1}
	    and #packet{value=_, id=Id}
	    and {secure, Id, _},
	    State) ->
    {[{reply, {ok, sell, Id}}, noreply,
      noreply, noreply], State + (V1)};
handle_join(stop, _) ->
    {stop, normal}.
