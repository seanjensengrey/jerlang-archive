-module(test_counter).
-compile({parse_transform, jerlang_gen_joins_parse}).
-behaviour(jerlang_gen_joins).

-export([init/1, handle_join/2, terminate/0]).
-export([start/0, stop/0, count/1, tick/0, wait/0, test/0]).


start() ->
    {ok, _} = gen_joins:start({local, ?MODULE}, ?MODULE, [], []).

stop() ->
     ok.

count(Value) ->
    gen_joins:cast(?MODULE, {count, Value}).

tick() ->
    gen_joins:cast(?MODULE, tick).

wait() ->
    gen_joins:call(?MODULE, wait).

test() ->
    gen_joins:call(?MODULE, test).

terminate() ->
    gen_joins:call(?MODULE, stop).

init(_Args) ->
    2.

handle_join({count, N} and tick, State) ->
    io:format("Handle join, count '~p' in  '~p' from '~p' and state: ~p~n", [N, count, tick, State]),
    count(N - 1),
    {[noreply, noreply], State+10};
handle_join({count, 0} and wait, State) ->
    io:format("Handle join, Count(0) ~p and final state '~p'~n",
	      [finished, State]),
    {[noreply, {reply, ok}], State}.
