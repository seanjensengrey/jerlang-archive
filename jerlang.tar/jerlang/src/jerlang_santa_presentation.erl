-module(jerlang_santa_presentation).

-export([test_suite/0]).
-export([test_santa_claus_limited/1]).
-export([start_reindeer/0, start_elves/0, start_santa/0]).
-export([worker0/4]).
-import(jerlang_misc, [generate_seed/1, average/1]).

test_suite() ->
    jerlang_gen_joins_test_santa_parse:start(),
    start_reindeer(),
    ok.

test_santa_claus_limited(Counter) ->
    io:format("testing santa stuff limited~n", []),
    jerlang_gen_joins_test_santa_parse:start(),
    [spawn_link(?MODULE, worker0,
		[jerlang_gen_joins_test_santa_parse,
		 Counter, elf, Id]) || Id <- lists:seq(1,10)],
    [spawn_link(?MODULE, worker0,
		[jerlang_gen_joins_test_santa_parse,
		 Counter, reindeer, Id]) || Id <- lists:seq(1,9)],
    ok = jerlang_gen_joins_test_santa_parse:status({Counter, Counter}),
    %% Could use joins here ? :)
    ok =
	receive
	    {'EXIT', _, A} when (A /= normal) ->
		io:format("EXIT: ~p~n", [A]),
		error
	after 0 ->
		ok
	end.

start_santa() ->
    jerlang_gen_joins_test_santa_parse:start(),
    receive
	ok ->
	    ok
    end.

start_reindeer() ->
    Counter = 16,
        io:format("~p has ~p~n", [ok, global:registered_names()]),
    [spawn_link(?MODULE, worker0,
		[jerlang_gen_joins_test_santa_parse,
		 Counter, reindeer, Id]) || Id <- lists:seq(1,9)],
    receive
	ok ->
	    ok
    end.

start_elves() ->
    Counter = 16, 
    [spawn_link(?MODULE, worker0,
		[jerlang_gen_joins_test_santa_parse,
		 Counter, elf, Id]) || Id <- lists:seq(1,10)],
    receive
	ok ->
	    ok
    end.

worker0(Module, Num, Type, Id) ->
    generate_seed(Id),
    net_adm:ping(hubert@ciapek),
%    io:format("~p has ~p~n", [Id, global:registered_names()]),
    worker1(Module, Num, Type, Id).

worker1(_Module, 0, Type, Id) ->
    io:format("[~p ~p] finished.~n", [Type, Id]),
    ok;
worker1(Module, Num, Type, Id) ->
    receive after random:uniform(1000) -> ok end,
    io:format("[~p ~p] waiting~n", [Type, Id]),
    Res =
	try
	    ok = Module:Type(),
%	    io:format("DONE.~n", []),
	    Done = list_to_atom(atom_to_list(Type) ++ "_done"),
	    receive after random:uniform(1000) -> ok end,
	    io:format("[~p ~p] returning ~n", [Type, Id]),
	    Module:Done(),
	    ok
    catch
	_:_ ->
	    error
    end,
    case Res of
	ok ->
	    worker1(Module, Num-1, Type, Id);
	error ->
	    ok
    end.
