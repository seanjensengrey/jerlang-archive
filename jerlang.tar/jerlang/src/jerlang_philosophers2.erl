-module(jerlang_philosophers2).
-export([philosopher/3,
	 waiter/2,
	 test/0]).

-compile({parse_transform, jerlang_parse}).

%% Note: probably the best solution, without
%% the waiter would be if we had distributed
%% joins

philosopher(Number, Name, Waiter) ->
    philosopher_think(Name),
    Waiter ! {order, self(), Number},
    {F1, F2} =
	receive
	    {forks, Left, Right} ->
		{Left, Right}
	end,
    philosopher_eat(Name),
    Waiter ! {fork, F1},
    Waiter ! {fork, F2},
    philosopher(Number, Name, Waiter).

philosopher_eat(Name) ->
    io:format("Philosopher ~p eats...~n", [Name]),
    timer:sleep(random:uniform(1000)).

philosopher_think(Name) ->
    io:format("Philosopher ~p thinks...~n", [Name]),
    timer:sleep(random:uniform(1000)).

waiter(Name, Size) ->
    receive
	{order, Phil, Number} and {fork, Left} and {fork, Right}
	when ((Left - 1) rem Size) == Right ->
	    Phil ! {forks, Number, (Number -1) rem Size}
    end,
    waiter(Name, Size).

test() ->
    Size = 10,
    W = spawn(?MODULE, waiter, [adam, Size]),
    [spawn(?MODULE, philosopher, [Id, Id, W]) || Id <- lists:seq(1, Size)],
    [W ! {fork, Id} || Id <- lists:seq(1, Size)],
    receive
	ok ->
	     nothing
    end.
