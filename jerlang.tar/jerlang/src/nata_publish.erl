-module(nata_publish).

-include("nata.hrl").

-define(DELAY, 5000).

-export([start/1]).

start(State) ->
    init(State),
    publish(State).

init({_, Seed, _Key, _Type}) ->
    {A1, A2, A3} = now(),
    random:seed(A1+Seed, A2*Seed, A3*Seed),
    io:format("[Producer ~p]:  Start ~n", [Seed]),
    ok.

publish({Exchange, Seed, Key, normal}=State) ->
    timer:sleep(random:uniform(?DELAY)),
    io:format("[Producer ~p]:  publish message [~p]~n", [Seed, Key]),
    Exchange:publish(#msg{key=Key,
			  id=none,
			  value={test, Seed}}),
    check_proceed(State).

check_proceed({_, Seed, _, _} = State) ->
    receive
	stop ->
	    io:format("[Producer ~p]:  stop~n", [Seed])
    after 0 ->
	    publish(State)
    end.
