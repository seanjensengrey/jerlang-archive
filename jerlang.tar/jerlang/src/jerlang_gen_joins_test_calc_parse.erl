-module(jerlang_gen_joins_test_calc_parse).
-behaviour(jerlang_gen_joins).

-compile({parse_transform, jerlang_gen_joins_parse}).

-export([init/1, handle_join/2, terminate/0]).
-export([start/0, stop/0, add/1, result/0, elf/1]).

start() ->
    jerlang_gen_joins:start({local, ?MODULE}, ?MODULE, [], []).

stop() ->
    ok.

terminate() ->
    jerlang_gen_joins:call(?MODULE, stop).

init(_Args) ->
    {ok, {valid, 17}}.

add(Number) ->
    jerlang_gen_joins:cast(?MODULE, {add, Number}).

result() ->
    jerlang_gen_joins:call(?MODULE, result).

elf(Arg) ->
    jerlang_gen_joins:cast(?MODULE, Arg).

handle_join({add, One} and {add, Two}, {valid, Num}) when (One > 2) ->
    io:format("*Handle join [parse_transform]*: Adding two numbers: [~p][~p]~n", [One, Two]),
    {[noreply, noreply], {valid, Num+One+Two}};
%handle_join({add, One} and {add, One}, {ok, B} = State) when (One > 2) ->
%    io:format("*Handle join [parse_transform]*: Nothing~n",
%	      []),
%    {[noreply, noreply], noth};

handle_join(result, {valid, Res}=State) when (Res > 5) ->
    io:format("*Handle join [parse_transform]*: RESULT ~p~n",
	      [Res]),
    {[{reply, Res+10}], State};
handle_join(elf and {elf, Num} and {elf, Part}, {valid, Part}=State)
  when (Num > 5) ->
    io:format("*Handle join*: ELF MATCHES with ~p~n", [Num]),
    {[noreply, noreply, noreply], State}.
