-module(jerlang_santa_claus_minimal).
-export([start/1, time_santa_script/1]).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.

santa(Main, Counter, Limit) ->
    io:format("It was a long night. Time to bed~n"),
    Group = 
	receive
	    {reindeer, Pid1} and {reindeer, Pid2} and 
	    {reindeer, Pid3} and {reindeer, Pid4} and
	    {reindeer, Pid5} and {reindeer, Pid6} and 
	    {reindeer, Pid7} and {reindeer, Pid8} and
	    {reindeer, Pid9} ->
		io:format("Ho, ho, ho! Let's deliver presents!~n"),
		[Pid1, Pid2, Pid3, Pid4,
		 Pid5, Pid6, Pid7, Pid8, Pid9];
	    {elf, Pid1} and {elf, Pid2} and {elf, Pid3} ->
		io:format("Ho, ho, ho! Let's discuss R&D possibilites!~n"),
		[Pid1, Pid2, Pid3]
    end,
    [ Pid ! ok || Pid <- Group],
    NCounter =
	case Counter < Limit of
	    true ->
		Counter + 1;
	    false ->
		Main ! stop,
		exit(normal)
	end,

    %% Synchronise on return of the animals
    receive
	{r, done} and {r, done} and {r, done} and
	{r, done} and {r, done} and {r, done} and
	{r, done} and {r, done} and {r, done} ->
	    ok;
	{e, done} and {e, done} and {e, done} ->
	    ok
    end,
    santa(Main, NCounter, Limit).

worker(Santa, Type, Id, Action, Ans) ->
    generate_seed(Id),
    worker1(Santa, Type, Id, Action, Ans).
    
worker1(Santa, Type, Id, Action, Ans) ->
    receive after random:uniform(1000) -> ok end,
    Santa ! {Type, self()},
    io:format("~p ~p: Waiting at the gate~n", [Type, Id]),
    receive ok -> ok end,    
    io:format("~p ~p: ~p~n", [Type, Id, Action]),
    Santa ! {Ans, done},
    worker1(Santa, Type, Id, Action, Ans).

generate_seed(Seed) ->
    {A1, A2, A3} = now(),
    random:seed(A1+Seed, A2*Seed, A3).

start(Counter) ->
    Pid = self(), 
    Santa = spawn(fun() -> santa(Pid, 0, Counter) end),
    [spawn(fun() -> worker(Santa, reindeer, I, " delivering toys.\n", r) end)
      || I <- lists:seq(1, 9)],
    [spawn(fun() -> worker(Santa, elf, I, " meeting in the study.\n", e) end)
     || I <- lists:seq(1, 10)],
    receive
	stop ->
	    ok
    end.

time_santa_script(Iter) ->
    {Time, _}
	= timer:tc(?MODULE,
		   start, [Iter]),
    
    io:format("Santa ~p took: ~p seconds~n",
	      [Iter, Time/1000000]).
