-module(joe_challenge).

-import(jerlang_misc, [generate_seed/1, average/1]).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.

-export([start/3, start_timer/0, start_timer/1]).

-define(REPEAT, 3).

start(Size, N, Delay) ->
    Main = self(),
    Pids = [ spawn_link(fun() -> worker(Id, N, Main, Delay) end)
	     || Id <- lists:seq(1, Size)],
    setup(add(Pids)),
    receive
	ok ->
	    ok
    end.

add([A,B,C | _Rest]=List) ->
    List ++ [A,B,C].

setup([_, _, _]) ->
    finished;
setup([A, B, C, D | Rest]) ->
    A ! {partners, B, C, D},
    setup([B, C, D | Rest]).

worker(Id, N, MasterPid, Delay) ->
    generate_seed(Id),

    receive
	{partners, Pid1, Pid2, Pid3} ->
	    worker1(Id, Pid1, [Pid2, Pid3], N, Delay)
    end,
    finalise(Id, MasterPid).

worker1(1, _, _, 0,_) ->
    ok;
worker1(1, PidNext, Pids, N, Delay) ->
    Msg = {msg, route, N},
    %% Could use list comprehensions, but want to
    %% leave space for delays
    send_synchr(Delay, {synchr, 1}, Pids),
    

    case Delay of 
	true ->
	    receive after random:uniform(1000) -> ok end;
	_ ->
	    ok
    end,
    PidNext ! Msg,

    %% Proper synchron on the all round
    receive
	{msg, route, N} and {synchr, _} and {synchr, _} ->
	    ok
    end,
    worker1(1, PidNext, Pids, N - 1, Delay);
worker1(_, _, _, 0, _) ->
    ok;
worker1(Id, PidNext, Pids, N, Delay) ->
    Synchr = {synchr, Id},
    %% Could use list comprehensions, but want to
    %% leave space for delays
    send_synchr(Delay, Synchr, Pids),
    Msg = 
	receive
	    {msg, route, Val} and {synchr, _} and {synchr, _} ->
		{msg, route, Val}
	end,
    PidNext ! Msg,
    worker1(Id, PidNext, Pids, N - 1, Delay).

finalise(1, MasterPid) ->
    MasterPid ! ok;
finalise(_, _) ->
    ok.

send_synchr(true, Msg, Pids) ->
    lists:foreach(
      fun(Pid) ->
	      receive after random:uniform(1000) -> ok end,
	      Pid ! Msg
      end, Pids);
send_synchr(false, Msg, Pids) ->
    [Pid ! Msg || Pid <- Pids].

start_timer() ->
    start_timer(false).

start_timer(Delay) ->
    io:format("Measuring modified Joe Armstrong's challenge~n", []),
    Tests = [2000, 4000, 6000, 8000, 10000, 12000, 14000,
	     16000, 18000, 20000, 22000, 24000, 26000, 28000, 30000],
    Rounds = [2, 4, 8, 16, 32, 64, 128],

    lists:foreach(
      fun(Round) ->
	      lists:foreach(
		fun(Processes) ->
			Result = 
			    lists:map(
			      fun(_) ->
				      {Time, _} =
					  timer:tc(?MODULE, start,
						   [Processes, Round, Delay]),
				      Time
			      end, lists:seq(1, ?REPEAT)),
			
			io:format("Procs: ~p Round: ~p Time: ~p seconds~n",
				  [Processes, Round, (average(Result)/1000000)])
		end, Tests)
      end, Rounds),
    ok.
