-module(multiple_producers_test).

-export([packet_generator/1]).
-export([synchronize/2]).
-export([buy/2, deposit/1, secure/2]).


-define(SERVER, multiple_producers).
-define(RANGE, 1000).
-define(SLEEP, 1000).
-define(RATIO, 2).

%%-record(packet,{id, value}).

-export([start/3, test_suite/1,
	 start_synchro/3, start_buyers/2,
	 start_deposit/1, start_secure/2]).

start(Size, Timeout, SyncProc) ->
    {ok, _} = ?SERVER:start(),
    lists:foreach(
      fun(Id) ->
	      spawn_link(?MODULE, packet_generator, [Id])
      end, lists:seq(1, Size)),
    Rounded = erlang:round(Size/?RATIO),
    TestPid = self(),
    TMiliSec = timer:seconds(Timeout),
    spawn_link(fun() -> start_synchro(SyncProc, TMiliSec, TestPid) end),
    spawn_link(fun() -> start_buyers(Rounded, Size) end),
    spawn_link(fun() -> start_deposit(Rounded) end),
    spawn_link(fun() -> start_secure(Rounded, Size) end),
    Final = collect_data(5, 0),
    io:format("Result: ~p ~p ~p ~p~n", [Timeout, Size, SyncProc, Final]),
    Final.

collect_data(0, Result) ->
    Result;
collect_data(N, Result) ->
    V = 
	receive
	    {partial, A} ->
		A
	end,
    collect_data(N - 1, Result + V).

packet_generator(Id) ->
    random:seed(Id*Id, Id + Id, Id * Id + Id),
    packet_generator0(Id).
    
packet_generator0(Id) ->
    timer:sleep(random:uniform(?SLEEP)),
    Value = random:uniform(?RANGE),
    ?SERVER:sell(Id, Value),
    packet_generator0(Id).

start_general(Size, Fun) ->
    lists:foreach(
      fun(Id) ->
	      Fun(Id)
      end, lists:seq(1, Size)),
    receive
	ok ->
	    ok
    end.

start_synchro(Size, Timeout, Pid) ->
    Start = erlang:now(),
    Fun = fun(A) ->
		  spawn_link(?MODULE, synchronize,
			[A, {Pid, Start, Timeout}])
	  end,
    start_general(Size, Fun).

start_buyers(Size, Range) ->
    Fun = fun(A) -> spawn_link(?MODULE, buy, [A, Range]) end,
    start_general(Size, Fun).

start_deposit(Size) ->
    Fun1 = fun(A) -> spawn_link(?MODULE, deposit, [A]) end,
    start_general(Size, Fun1).

start_secure(Size, Range) ->
    Fun2 = fun(B) -> spawn_link(?MODULE, secure, [B, Range]) end,
    start_general(Size, Fun2).
 
synchronize(Id, Args) ->
    random:seed(Id*1, Id*2, Id*3),
    synchronize0(Id, Args, 0).

synchronize0(Id, {Pid, Start, Timeout}=Args, Res) ->
    timer:sleep(random:uniform(?SLEEP)),
    MiliDiff = erlang:round(
		 timer:now_diff(
		   erlang:now(), Start)/1000), %% Microseconds
    case MiliDiff > Timeout of
	true ->
	    Pid ! {partial, Res};
	_ ->
	    try
		?SERVER:notify(Timeout - MiliDiff),
		synchronize0(Id, Args, Res + 1)
	    catch
		exit:{timeout, _} ->
		    Pid ! {partial, Res}
	    end
    end.

buy(Id, Range) ->
    random:seed(Id*Id, Id*Id, Id*Id),
    buy0(Id, Range).

buy0(Id, Range) ->
    timer:sleep(random:uniform(?SLEEP)),
    Value = random:uniform(?RANGE),
    BId = random:uniform(Range),
    
    ?SERVER:buy(BId, Value, random),
    buy0(Id, Range).
    

deposit(Id) ->
    random:seed(Id*4, Id, Id*4),
    deposit0(Id).

deposit0(Id) ->
    timer:sleep(random:uniform(?SLEEP)),
    Value = random:uniform(?RANGE),
    
    ?SERVER:deposit(Value),
    deposit0(Id).

secure(Id, Range) ->
    random:seed(Id*Id, Id*Id, Id*Id),
    secure0(Id, Range).

secure0(Id, Range) ->
    timer:sleep(random:uniform(?SLEEP)),
    BId = random:uniform(Range),
    
    ?SERVER:credentials(BId, random),
    secure0(Id, Range).

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Gather test data

test_suite(_) ->
    Notifiers = 10,
    Timeouts = [10, 20, 40, 80, 160, 320, 540],
    Producers = [2, 4, 8, 16, 32, 64, 128, 256],
    lists:foreach(
      fun(Timeout) ->
	      Result = 
		  lists:map(
		    fun(P) ->
			    start(P, Timeout, Notifiers)
		    end, Producers),
	      io:format("~p", [Timeout]),
	      [io:format(" ~p", [R]) || R<- Result],
	      io:format("~n", [])
      end, Timeouts),
    io:format("Done.", []).
    
    
    

