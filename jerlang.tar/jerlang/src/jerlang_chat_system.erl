-module(jerlang_chat_system).
-compile({parse_transform, jerlang_gen_joins_parse}).

-behaviour(jerlang_gen_joins).

-export([init/1, handle_join/2, start/0, terminate/0]).
-export([login/1, logout/1, private_channel/2]).
-export([send/2, send/3, close_room/2]).

-record(user, {id, pid}).
-record(system, {users, rooms=[]}).

-define(SERVER, jerlang_gen_joins).


start() ->
    ?SERVER:start({local, ?MODULE}, ?MODULE, [], []).

terminate() ->
    ?SERVER:call(?MODULE, stop).

init(_) ->
    {ok, #system{users=dict:new(), rooms=dict:new()}}.

login(User) ->
    ?SERVER:call(?MODULE, {login, {User, self()}}).

logout(User) ->
    ?SERVER:call(?MODULE, {logout, {User, self()}}).

private_channel(User1, User2) ->
    ?SERVER:call(?MODULE, {private, {User1, self()}, User2}).

send(User, Msg) ->
    ?SERVER:cast(?MODULE, {msg, {User, self()}, Msg}).

send(User, Room, Msg) ->
    ?SERVER:cast(?MODULE, {msg, {User, self()}, Room, Msg}).

close_room(User, Room) ->
    ?SERVER:call(?MODULE, {msg, close, {User, self()}, Room}).

%% ------------------------------------------------

handle_join({login, User}, S) ->
    {NS, Result} = add_login(
		     valid_user(User, S),
		     User, S),

    {[{reply, Result}], NS};
handle_join({private, {User1, Pid1}, User2}
	    and {private, {User2, Pid2}, User1},
	    #system{rooms=Rs}=S) ->
    %% Open private channel
    {Reply, NS} = 
	case valid_user({User1, Pid1}, S)
	    and valid_user({User2, Pid2}, S) of
	    true ->
		%%  Assume unique enough
		Room = make_ref(),
		?SERVER:cast(?MODULE, {room, Room}),
		{{room, Room}, S#system{rooms=dict:store(Room,
							 [User1, User2],
							 Rs)}};
	    false ->
		{{error, invalid_authorization}, S}
	end,
    {[{reply, Reply}, {reply, Reply}], NS};
handle_join({room, Room} and {msg, close, User, Room}, S) ->
    % Determine whether the user belongs to this room
    Result = 
	case other_user(Room, User, S) of
	    {error, invalid} ->
		%% Invalid user tries to close the room
		?SERVER:cast(?MODULE, {room, Room}),
		{error, invalid_user};
	    {ok, Pid2} ->
		Pid2 ! {chat, private, Room, User, close_room_request},
		{ok, closed}
	end,
    NS = remove_room(Room, S),
    {[noreply, {reply, Result}], NS};
handle_join(prop({room, Room}) and {msg, User, Room, Msg}, S) ->
    %% Find users of the room
    case other_user(Room, User, S) of
	{ok, Pid} ->
	    Pid ! {chat, private, Room, User, Msg};
	_ ->
	    %% Ignore msg
	    ok
    end,
    {[noreply, noreply], S};
handle_join({msg, User, Msg}, S) ->
    case valid_user(User, S) of
	true ->
	    send_all(S, User, Msg);
	_ ->
	    %% Ignore msg
	    ok
    end,
    {[noreply], S}.
     

%% ------------------------------------------------
add_login(true, _, S) ->
    {S, {error, invalid_user}};
add_login(_, {User, Pid}, #system{users=Users}=S) ->
    {S#system{users=
	      dict:store(User, #user{id=User, pid=Pid}, Users)},
     valid}.

valid_user({User, Pid}, #system{users=Users}) ->
    try
	#user{pid=Pid} = dict:fetch(User, Users),
	true
    catch
	_:_ ->
	    false
    end.

send_all(#system{users=Us}, User, Msg) ->
    lists:map(
      fun({_, #user{pid=Pid}}) ->
	      Pid ! {chat, public, User, Msg}
      end, dict:to_list(Us)),
    ok.

other_user(Room, {User, _}, #system{users=Us, rooms=Rs}) ->
    case other_user0(dict:fetch(Room, Rs), User) of
	{ok, Other} ->
	    #user{pid=Pid} = dict:fetch(Other, Us),
	    {ok, Pid};
	Error ->
	    Error
    end.

other_user0([User, Other], User) ->
    {ok, Other};
other_user0([Other, User], User) ->
    {ok, Other};
other_user0(_, _) ->
    {error, invalid}.

remove_room(Room, S) ->
    dict:erase(Room, S).
