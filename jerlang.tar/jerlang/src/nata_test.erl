-module(nata_test).

-export([start/0, start_pres_exchange/0]).
-export([start_pres_producer/2, start_pres_consumer/4]).

-define(EXCHANGE, nata_exchange).

start() ->
%    Keys = [a, b, c, a, b, c, a, b, c, b],
    Keys = [a,b,c],
    KeysChannels = [{a, 2, [2,3]},
		     {c, 3, [1,2]}],
    {ok, _} = nata_exchange:start(),
%    spawn(nata_subscribe, start, []),
    start_consumers(KeysChannels),
    start_producers(Keys),
    receive
	nothing ->
	    ok
    end.
%    nata_publish:start({nata_exchange, 1300, bb, normal}).

start_consumers(Conf) ->
    Ids = lists:seq(1, length(Conf)),
    IdsKeys = lists:zip(Ids, Conf),
    [spawn(nata_subscribe, start, [{?EXCHANGE, Id, Key, Synchr, Channels}]) 
     || {Id, {Key, Synchr, Channels}} <- IdsKeys],
    ok.

start_producers(Keys) ->
    Ids = lists:seq(1, length(Keys)),
    IdsKeys = lists:zip(Ids, Keys),
    [spawn(nata_publish, start, [{?EXCHANGE, Id, Key, normal}])
     || {Id, Key} <- IdsKeys].

block() ->
    receive
	stop ->
	    ok
    end.

start_pres_exchange() ->
    {ok, _} = nata_exchange:start(),
    block().

start_pres_consumer(Id, Key, Type, Channels) ->
    spawn(nata_subscribe, start, [{?EXCHANGE, Id, Key, Type, Channels}]),
    block().

start_pres_producer(Id, Key) ->
    spawn(nata_publish, start, [{?EXCHANGE, Id, Key, normal}]),
    block().
