-module(jerlang_gen_joins_test_santa).

-behaviour(jerlang_gen_joins).
-include("jerlang.hrl").

-export([init/1, handle_join/2, terminate/0]).
-export([start/0, stop/0, elf/0, reindeer/0]).
-export([elf_done/0, reindeer_done/0, status/1]).
-export([init_joins/1]).

start() ->
    jerlang_gen_joins:start({global, ?MODULE}, ?MODULE, [], []).

stop() ->
    jerlang_gen_joins:call({global, ?MODULE}, stop).

terminate() ->
    jerlang_gen_joins:call({global, ?MODULE}, stop).

init(_Args) ->
    {ok, {{0,0}, sleeping}}.

elf() ->
    jerlang_gen_joins:call({global, ?MODULE}, elf),
    ok.

elf_done() ->
    jerlang_gen_joins:cast({global, ?MODULE}, {done, elf}).


reindeer() ->
    jerlang_gen_joins:call({global, ?MODULE}, reindeer).

reindeer_done() ->
    jerlang_gen_joins:cast({global, ?MODULE}, {done, reindeer}).

status(Status) ->
    jerlang_gen_joins:call({global, ?MODULE}, {status, Status}, infinity).

init_joins(_) ->
    {ok, 
     [
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    {status, _, _} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([elf, elf],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([{status, A, B}],
	    {{C, D}, _})  when ((A =< C) and (B =< D))  ->
		true
	end, []}],
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    stop ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([stop],
	    _) ->
		true
	end, []}],
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{2, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						    false
					end
				end, msgs=[]}},
	{3, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{4, #pattern_joins{test=fun(Value) ->
					case Value of
						{done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{5, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{6, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{7, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{8, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{9, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, reindeer} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([{done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []},
       {fun([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer}],
	    {_, awake_reindeer}) ->
		true
	end, []}],
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, elf} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{2, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, elf} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{3, #pattern_joins{test=fun(Value) ->
					case Value of
					    {done, elf} ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([{done, elf}, {done, elf}],
	    {_, awake_elf}) ->
		true
	end, []},
       {fun([{done, elf}, {done, elf}, {done, elf}],
	    {_, awake_elf}) ->
		true
	end, []}],
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    elf ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{2, #pattern_joins{test=fun(Value) ->
					case Value of
					    elf ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{3, #pattern_joins{test=fun(Value) ->
					case Value of
					    elf ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([elf, elf],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([elf, elf, elf],
	    {_, sleeping}) ->
		true
	end, []}],
      [[{1, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{2, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{3, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{4, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{5, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{6, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{7, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{8, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}},
	{9, #pattern_joins{test=fun(Value) ->
					case Value of
					    reindeer ->
						true;
					    _ ->
						false
					end
				end, msgs=[]}}],
       {fun([reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer, reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer, reindeer, reindeer,
	     reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer, reindeer, reindeer,
	     reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []},
       {fun([reindeer, reindeer, reindeer,
	     reindeer, reindeer, reindeer,
	     reindeer, reindeer, reindeer],
	    {_, sleeping}) ->
		true
	end, []}]
    ]}.

handle_join({status, {A, B}}, {{C, D}, _}=S) when ((A =< C) and (B =< D))  ->
    io:format("I am done ~p~n", [{C, D}]),
    {[{reply, ok}], S};
handle_join(stop, _) ->
    io:format("Stopping the server~n", []),
    {stop, normal};
handle_join([{done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer},
	     {done, reindeer}, {done, reindeer}, {done, reindeer}],
	    {Counter, awake_reindeer}) ->
    io:format("All reindeers returned~n",[]),
    {[ noreply || _ <- lists:seq(1,9)], {Counter, sleeping}};

handle_join([{done, elf}, {done, elf}, {done, elf}],
	    {Counter, awake_elf}) ->
    io:format("All elves returned~n",[]),
    {[ noreply || _ <- lists:seq(1,3)], {Counter, sleeping}};

handle_join([reindeer, reindeer, reindeer, 
	    reindeer, reindeer, reindeer, 
	    reindeer, reindeer, reindeer],
	    {{Reindeers, Elves}, sleeping}) ->
    io:format("Reindeers delivering presents~n",[]),
    {[ {reply, ok} || _ <- lists:seq(1,9)], {{Reindeers+1, Elves}, awake_reindeer}};

handle_join([elf, elf, elf],
	    {{Reindeers, Elves}, sleeping}) ->
    io:format("Elves discussing R&D possibilities~n",[]),
    {[ {reply, ok} || _ <- lists:seq(1,3)], {{Reindeers, Elves+1}, awake_elf}}.
