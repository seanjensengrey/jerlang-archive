-module(jerlang_wide_finder).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.

-export([start/1, slave/2]).

%% The best Bin Buffer Size is 4096
-define(BUFFER_SIZE, 4096).

start(FileName) ->
    divide_problem(FileName),
    self() ! {workers, 0},
    gather_results(dict:new()).

divide_problem(FileName) ->
    {ok, File} = file:open(FileName, [raw, binary]),
    create_chunks(File, [], self(), 0).

create_chunks(File, PrevTail, Master, Num) ->
    case file:read(File, ?BUFFER_SIZE) of
	eof ->
	    Master ! {done, Num},
	    file:close(File);
	{ok, Bin} ->
	    {Data, NextTail} =
		split_on_last_newline(PrevTail ++ binary_to_list(Bin)),
	    spawn(?MODULE, slave, [Data, Master]),
	    Master ! {new_chunk, Num},
	    create_chunks(File, NextTail, Master, Num+1)
    end.

slave(Data, Master) ->
    Result = scan_lines(Data),
    Master ! {result, Result}.

%%  Different version
%%  where there is a limited thread pool
%%  and works continuesly request work.
req_slave(Master) ->
    Data =
	receive
	    {scan, Data} ->
		Data;
	    {finish, Master} ->
		exit(normal)
	end,
    Result = scan_lines(Data),
    Master ! {result, Result},
    req_slave(Master).
	    
    
split_on_last_newline(List) -> split_on_last_newline_1(lists:reverse(List), []).
split_on_last_newline_1(List, Tail) ->
    case List of
        []         -> {lists:reverse(List), []};
        [$\n|Rest] -> {lists:reverse(Rest), Tail};
        [C|Rest]   -> split_on_last_newline_1(Rest, [C | Tail])
    end.

gather_results(Store) ->
    receive
%	{workers, 0} and {done, Num} and nothing->
%	    io:format("Job done. Theoretically done ~p~n", [Num]),
%	    print_result(Store);
	{workers, N} and {new_chunk, _} ->
%	    io:format("New chunk. Id [~p]~n", [Id]),
	    self() ! {workers, N+1},
	    gather_results(Store);
	{workers, N} and {result, PStore} ->
            NStore = dict:merge(fun (_, V1, V2) -> V1 + V2 end, Store, PStore),
	    self() ! {workers, N-1},
	    gather_results(NStore);
	{workers, 0} and {done, Num}->
	    io:format("Job done. Theoretically done ~p~n", [Num]),
	    print_result(Store)
    end.


%%%% --Proper matching

print_result(Dict) ->
    SortedList = lists:reverse(lists:keysort(2, dict:to_list(Dict))),
    [io:format("~p\t: ~s~n", [V, K]) || {K, V} <- lists:sublist(SortedList, 10)].

scan_lines(List) -> scan_lines_1(List, [], dict:new()).
scan_lines_1(List, Line, Dict) -> 
    case List of
        [] -> match_and_update_dict(lists:reverse(Line), Dict);
        [$\n|Rest] ->
            scan_lines_1(Rest, [], match_and_update_dict(lists:reverse(Line), Dict));
        [C|Rest] ->
            scan_lines_1(Rest, [C | Line], Dict)
    end.

match_and_update_dict(Line, Dict) ->
    case process_match(Line) of
        false -> Dict;
        {true, Word} -> 
            dict:update_counter(Word, 1, Dict)
    end.
    
process_match(Line) ->
    case Line of
        [] -> false;
        "GET /ongoing/When/"++[_,_,_,$x,$/,Y1,Y2,Y3,Y4,$/,M1,M2,$/,D1,D2,$/|Rest] -> 
            case match_until_space(Rest, []) of
                [] -> false;
                Word -> {true, [Y1,Y2,Y3,Y4,$/,M1,M2,$/,D1,D2,$/] ++ Word}
            end;
        [_|Rest] -> 
            process_match(Rest)
    end.
    
match_until_space(List, Word) ->
    case List of
        [] -> [];
        [$.|_] -> [];
        [$ |_] -> lists:reverse(Word);
        [C|Rest] -> match_until_space(Rest, [C | Word])
    end.

