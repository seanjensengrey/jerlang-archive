-module(jerlang_santa_claus).
-export([santa/3]).
-export([start_timer/0]).
-export([start/0, start/2]).

-ifdef(use_joins_vm).
-compile({parse_transform, jerlang_vm_parse}).
-else.
-compile({parse_transform, jerlang_parse}).
-endif.

santa(Arg1, Arg2, Limits) ->
    santa(Arg1, Arg2, Limits, {0, 0}).

santa(Arg1, Arg2, Limits, {RN, EN}) ->
    %% Currently there is no way to dynamically
    %% generate patterns
    Res = receive
	{reindeer, Pid1, Ref1} and {reindeer, Pid2, Ref2} and 
	{reindeer, Pid3, Ref3} and {reindeer, Pid4, Ref4} and
	{reindeer, Pid5, Ref5} and {reindeer, Pid6, Ref6} and 
	{reindeer, Pid7, Ref7} and {reindeer, Pid8, Ref8} and
	{reindeer, Pid9, Ref9} ->
	    send_confirmation([{Pid1, Ref1}, {Pid2, Ref2},
			       {Pid3, Ref3}, {Pid4, Ref4},
			       {Pid5, Ref5}, {Pid6, Ref6},
			       {Pid7, Ref7}, {Pid8, Ref8},
			       {Pid9, Ref9}], done),
	    santa_says("Reindeers delivering presents"),
	    reindeers;
	{elf, Pid1, Ref1} and {elf, Pid2, Ref2}
	  and {elf, Pid3, Ref3} ->
	    send_confirmation([{Pid1, Ref1}, {Pid2, Ref2},
			       {Pid3, Ref3}], done),
	    santa_says("Elves discussing R&D possibilities"),
	    elves;
	{ork, _Pid}  ->
	    ork

    end,
    Counters = case Res of
	reindeers ->
	    receive
		{job_done, reindeer, Pid1, Ref1} and
		{job_done, reindeer, Pid2, Ref2} and
		{job_done, reindeer, Pid3, Ref3} and
		{job_done, reindeer, Pid4, Ref4} and
		{job_done, reindeer, Pid5, Ref5} and
		{job_done, reindeer, Pid6, Ref6} and
		{job_done, reindeer, Pid7, Ref7} and
		{job_done, reindeer, Pid8, Ref8} and
		{job_done, reindeer, Pid9, Ref9} ->
		    send_confirmation([{Pid1, Ref1}, {Pid2, Ref2},
				       {Pid3, Ref3}, {Pid4, Ref4},
				       {Pid5, Ref5}, {Pid6, Ref6},
				       {Pid7, Ref7}, {Pid8, Ref8},
				       {Pid9, Ref9}], finished),
		    {RN+1, EN}
	    end;
	elves ->
	    receive
		{job_done, elf, Pid1, Ref1} and
		{job_done, elf, Pid2, Ref2} and
		{job_done, elf, Pid3, Ref3} ->
		    send_confirmation([{Pid1, Ref1}, {Pid2, Ref2},
				       {Pid3, Ref3}], finished),
		    {RN, EN+1}
	    end;
	ork ->
	    {RN, EN}
    end,
    santa_continuation(Arg1, Arg2, Limits, Counters).

santa_continuation(Arg1, Arg2, {infinite, infinite}=L, Counters) ->
    santa_says("Going to sleep"),
    santa(Arg1, Arg2, L, Counters);
santa_continuation(_, _, {RLimit, ELimit}, {RN, EN})
  when (RLimit =< RN) and (ELimit =< EN) ->
    io:format("Simulation finished [~p | ~p] for [~p | ~p]~n",
	      [RN, EN, RLimit, ELimit]);
santa_continuation(Arg1, Arg2, Limits, Counters) ->
    santa_says("Going to sleep"),
    santa(Arg1, Arg2, Limits, Counters).
	    
send_confirmation(List, Message) ->
    [ Pid ! {Ref, Message} || {Pid, Ref} <- List].
	    
santa_says(Text) ->
    io:format("Santa: ~p~n", [Text]).

start() ->
    start(?MODULE, {infinite, infinite}).

start(Module, Args) ->
    santa_claus:start(Module, Args).

start_timer() ->
    santa_claus:start_timer(?MODULE).
