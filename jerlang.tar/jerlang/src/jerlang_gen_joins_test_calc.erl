-module(jerlang_gen_joins_test_calc).

-ifdef(use_joins_vm).
-define(GEN_JOINS, jerlang_vm_gen_joins).
-else.
-define(GEN_JOINS, jerlang_gen_joins).
-endif.
-behaviour(?GEN_JOINS).

-export([init/1, init_joins/1, handle_join/2, terminate/0]).
-export([start/0, stop/0, add/1, result/0, elf/1]).

-include("jerlang.hrl").

start() ->
    ?GEN_JOINS:start({local, ?MODULE}, ?MODULE, [], []).

stop() ->
    ok.

terminate() ->
    ?GEN_JOINS:call(?MODULE, stop).

init(_Args) ->
    {ok, {valid, 17}}.

init_joins(_) ->
    {ok,
     [
      [[{1, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       {add, _One} -> true;
				       _ -> false
				   end
			   end, msgs=[]}},
	{2, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       {add, _Two} -> true;
				       _ -> false
				   end
			   end, msgs=[]}}],
       {fun([{add, One}, {add, _Two}], {valid, _Num}) when (One > 2) ->
		true
	end, []}],
       %% FIXME: further reduction in 1?
       [[{3, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       result -> true;
				       _ -> false
				   end
			   end, msgs=[]}}],
       {fun([result], {valid, Res}) when (Res > 5) ->
		true
	end, []}],
       [[{4, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       elf -> true;
				       _ -> false
				   end
			   end, msgs=[]}},
	{5, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       {elf, _Num} -> true;
				       _ -> false
				   end
			   end, msgs=[]}},
	{6, #pattern_joins{test=
			   fun(Value) ->
				   case Value of
				       {elf, _Part} -> true;
				       _ -> false
				   end
			   end, msgs=[]}}],
       {fun([elf, {elf, Num}], _) when (Num > 5) ->
		true
	end, []},
       {fun([elf, {elf, Num}, {elf, Part}], {valid, Part}=_State)
	   when (Num > 5) ->
		true
	end, []}]
     ]}.
      
add(Number) ->
    ?GEN_JOINS:cast(?MODULE, {add, Number}).

result() ->
    ?GEN_JOINS:call(?MODULE, result).

elf(Arg) ->
    ?GEN_JOINS:cast(?MODULE, Arg).

%handle_join({add, One} and {add, Two}, State) ->
handle_join([{add, One}, {add, Two}], {valid, Num}) when (One > 2) ->
    io:format("*Handle join*: Adding two numbers: [~p][~p]~n", [One, Two]),
    {[noreply, noreply], {valid, Num+One+Two}};
handle_join([result], {valid, Res}=State) when (Res > 5) ->
    io:format("*Handle join*: RESULT ~p~n", [Res]),
    {[{reply, Res+10}], State};
handle_join([elf, {elf, Num}, {elf, Part}], {valid, Part}=State)
  when (Num > 5) ->
    io:format("*Handle join*: ELF MATCHES with ~p~n", [Num]),
    {[noreply, noreply, noreply], State}.
